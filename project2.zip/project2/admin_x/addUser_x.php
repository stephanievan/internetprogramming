<?php
echo "under construction!";
require_once("sqlSts.php");
$conn=connectDB();

if(isset($_POST['loginname']))
{
	$loginname=$_POST['loginname'];
}
$pwd=$_POST['password'];
$identity=$_POST['id'];
$privilege=$_POST['slevel'];
$issuperuser=0;
if(isset($_POST['suser']))
{
	$issuperuser=$_POST['suser'];
}
$siteid=$_POST['sid'];

$sql = "SELECT * from tblusers where UserLoginName = \"$loginname\" ";
$errorcheck = $conn->query($sql);

if(mysqli_num_rows($errorcheck) > 0) {
	echo "Login name has been taken.";
}


$query="INSERT INTO tblusers VALUES(\"$loginname\",\"$pwd\", \"$identity\", \"$privilege\", \"$issuperuser\", \"$siteid\") ";

$result=$conn->query($query);
if(!$result) die("Fatal error from Query");
else echo "User added.";

?>