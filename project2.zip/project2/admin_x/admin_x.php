<?php
  ob_start();
  session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style type="text/css">
     .space10 {
      height: 20px;
     }
    </style>
    <title>Admin</title>
  </head>
  <body>
  <?php
   require_once("./pageFormat.php");
   pageHeader("Admin", "logo.png");
    echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
               <a class="nav-item nav-link" href="editUser.php">Edit User</a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
            </nav>
        <hr class="style1"/>
EOT;
    require_once("sqlSts.php");
   
    $UserLoginName=$_SESSION['UserLoginName'];
    $conn=connectDB();
    $query="SELECT * FROM tblusers WHERE UserLoginName=\"$UserLoginName\" ";
    $result=$conn->query($query);
    if(!$result) die("Fatal error from query");
    else {
      while($row=$result->fetch_assoc()) {
        $userloginname=$row["UserLoginName"];
        $userpassword=$row["UserPW"];
        $userid=$row["Identity"];
        $userprivilege=$row["Privilege"];
        $userissuperuser=$row["IsSuperuser"];
        $userfksiteid=$row["fkSiteID"];
      }
    }

    echo<<<EOT

  <form action="./adminHandle.php" method="POST">
      Login:<br>
      <input type="text" name="loginname" value="$userloginname">
      <br><br>
      Password:<br>
      <input type="password" name="password" id="passId" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" value="$userpassword" required>
      <br><br>
      Identity:<br>
      <input type="text" name="id" value="$userid" readonly>
      <br><br>
      Security Level:<br>
      <input type="text" name="slevel" value="$userprivilege" readonly>
      <br><br>
      Superuser?<br>
      <input type="checkbox" name="suser" value="$userissuperuser" onclick="return false;" checked>
      <br><br>
      Site ID:<br>
      <input type="text" name="sid" value="$userfksiteid">
      <br><br>
      <input type="submit" value="Update">
      <br><br>
      <input type="button" value="Close Form">
      <br><br>
    </form> 

EOT;
?>


</body>