<?php
  ob_start();
  session_start();
  if(!isset($_SESSION['admin']))
{
  header("Location: ../superuserlogin.php");
  exit(0);
}
?>

<!--  SUPERUSER ADMIN PAGE The user can changeand savelogin name, password fields, and fkSiteId, then keep the other fields as read-only. Uses javascript and php to validate the password. The password must be at least 8 characters, mixed with uppercase, lowercase and digit. Ensures that the login name is unique. Includes menus to add, edit, and delete users, which move to theweb pages“addUser.php, editUser.php,and deleteUser.php”respectively. Includes menu to close form, which implements logout, and moves back to superuser login page. includes about menu: version control and authors’ information. -->

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style type="text/css">
     .space10 {
      height: 20px;
     }
     .inline-div {
      padding: 35px;
      display:inline-table;
     }
     .info {
      height: 100%;
      width:80%;
     }
     th, td {
      padding:15px;
      text-align:left;
     }
}
    </style>
    <title>Admin</title>
  </head>
  <body>
  <?php
    require_once("pageFormat.php");
    require_once("DBFuncs/sqlConn.php");
   pageHeader("Admin", "logo.png");
    echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
               <a class="nav-item nav-link" href="editUser.php">Edit User</a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
              <a class="nav-item nav-link" href="editTest.php">Edit Security Level</a>
              <a class="nav-item nav-link" href="edit.php">Edit Users</a>
              <a class="nav-item nav-link" href="about.php">About</a>
            </nav>
        <hr class="style1"/>
EOT;
        //checks if message is set when form is updated - from adminHandle.php
         if(isset($_GET['msg']))
        {
          $msg=$_GET['msg'];
          echo<<<EOT
          <div class="alert" role="alert">
            $msg
          </div>
EOT;
  }
    $UserLoginName=$_SESSION['UserLoginName'];
    $conn=connectDB();
    $query="SELECT * FROM tblusers WHERE UserLoginName=\"$UserLoginName\" ";
    $result=$conn->query($query);
    if(!$result) die("Fatal error from query");
    else {
      while($row=$result->fetch_assoc()) {
        $userloginname=$row["UserLoginName"];
        $userpassword=$row["UserPW"];
        $userid=$row["Identity"];
        $userprivilege=$row["Privilege"];
        $userissuperuser=$row["IsSuperuser"];
        $userfksiteid=$row["fkSiteID"];
      }
    }

    echo<<<EOT
<div>
<table class="info">
  <form action="./adminHandle.php" method="POST">
      <tr>
        <td colspan = "2">
          Login:<br>
          <input type="text" name="loginname" value="$userloginname">
        </td>
        <td>
          Password:<br>
          <!-- pattern is checked to validate password. required field doesn't allow user to submit form without filling this out (info not sent to database) -->
          <input type="password" name="password" id="passId" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" value="$userpassword" required>
        </td>
        <td colspan="2">
          Identity:<br>
          <!-- readonly doesn't allow user to change this -->
          <input type="text" name="id" value="$userid" readonly>
        </td>
      </tr>
      <tr>
        <td colspan="2">
          Security Level:<br>
          <!-- readonly doesn't allow user to change this -->
          <input type="text" name="slevel" value="$userprivilege" readonly>
        </td>
        <td colspan="2">
          Superuser?<br>
          <!-- onlick makes this uneditable to the user. checked attribute makes checkbox be checked. -->
          <input type="checkbox" name="suser" value="$userissuperuser" onclick="return false;" checked>
        </td>
        <td colspan="2">
          Site ID:<br>
          <input type="text" name="sid" value="$userfksiteid">
        </td>
      </tr>
      <td>
        <input type="submit" value="Update">
      </form>
      <td>
        <form action="superUserLogout.php">
          <input type="submit" value="Close Form"/>
        </form>
      </td>
    </table>
</div>

EOT;
?>


</body>