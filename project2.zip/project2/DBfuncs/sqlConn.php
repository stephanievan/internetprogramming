<?php

function connectDB()
{
	$host="localhost";
	$db="cadetstu";
	$user="root";
	$pwd="";

	$conn=new mysqli($host, $user, $pwd, $db);
	if($conn->connect_error) die("DB Connection Fatal Error");
	else
		return $conn;

}
?>