
<!-- searched the database for a UserLoginName like the partial name given -->
<?php
$dir=dirname(dirname(__FILE__));  
require_once ("/DBfuncs/sqlConn.php");
require_once("/DBFuncs/sqlSts.php");
if(isset($_GET["pUserName"]))
{
	$partName=$_GET["pUserName"];
	$conn=connectDB();
	$names=array(); //hold a list of names return from SQL
	$query="SELECT UserLoginName FROM tblusers WHERE UserLoginName like '$partName%' ORDER BY UserLoginName";
    $arr=getResultFromTable($conn,$query);  //arr['UserLoginName']="mis"....
    foreach ($arr as $record) {
    	 foreach ($record as $key => $value) {
    	 	array_push($names, $value);
    	 }
    	
    }
    $popStr=implode(" ",$names);  //php echp "major med minzt mis"
    
     echo $popStr;
}
?>