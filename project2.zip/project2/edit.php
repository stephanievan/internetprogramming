<?php
  ob_start();
  session_start();
  if(!isset($_SESSION['admin']))
{
  header("Location: superuserlogin.php");
  exit(0);
}
?>

<!-- "EditUser.php”, which can edit personnel. The editable fields include: login name, password, full name, security level,fkSiteIDand then check the box indicating whether this will be a superuser. You need to provide search function to help the client to get the userquickly. -->

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Edit User</title>
  </head>
  <body>
     <div class="container">
   
	    <?php
	     require_once "./DBfuncs/sqlConn.php";
       require_once "./DBfuncs/sqlSts.php";
	     require_once "optionSupportTest.php";
       require_once("pageFormat.php");
    pageHeader("Edit User", "logo.png");
     echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
              <a class="nav-item nav-link" href="editTest.php">Edit Security Level</a>
              <a class="nav-item nav-link" href="edit.php">Edit Users</a>
              <a class="nav-item nav-link" href="about.php">About</a>
            </nav>
        <hr class="style1"/>
EOT;
      echo<<<EOT
        <form action="edit.php" method="post">

    <label class="col-2"> Get user name</label>
            <input class="col-3" list="listNames"  id="loginNameJs" onkeyup="findPartName()" name="loginName">
            <datalist id="listNames">
              

            </datalist>
               
            <input class="btn btn-primary col-2" type="submit" value="Search">
     </form>
EOT;
	
	    $conn=connectDB();
	    $query="SELECT DISTINCT(UserSecGroup) FROM tblprivileges order by UserSecGroup";
	    $arr1=getResultFromTable($conn,$query);
        
        if(isset($_POST["loginName"]))
        {
        	$loginName=$_POST["loginName"];
        	$query="SELECT * FROM tblusers where UserLoginName= '$loginName' ORDER BY UserLoginName";
        }
        else 
	         $query="SELECT * FROM tblusers ORDER BY UserLoginName";
	    
	    $arr=getResultFromTable($conn,$query);
	 
	    $query="SELECT SiteID FROM tlkpsite";
        $arrSiteID= getResultFromTable($conn,$query);

        $query="SELECT Identity FROM tblusers";
        $arrIdt=getResultFromTable($conn,$query);

        $query="SELECT DISTINCT IsSuperuser FROM tblusers";
        $arrSuper=getResultFromTable($conn,$query);

        
	    //table header
        echo<<<EOT
			<table class="table table-hover">
			 <thead>
			  <tr>
			    <th>UserLoginName</th>
			    <th>UserPassword</th>
			    <th>Identity</th>
			    <th>Privilege</th>
			    <th>SuperUser</th>
			    <th>SiteID</th>
			  </tr>
   			</thead>
   			<tbody>
EOT;
	    foreach ($arr as $record) {
	    	//for the first record:
	    	// reocrd['UserLoginName']="abbott" 
	    	// record['UserPW']="Hello"....
	    	$pv=$record['Privilege'];
	        $oPriv=optionGen("securityId","securityName",$arr1,$pv);
	 
            $siteID=$record['fkSiteID'];
            $oSiteID=optionGen("siteID","siteName",$arrSiteID,$siteID);

            $identityId=$record['Identity'];
            $oIdentity=optionGen("identityId", "IdentityName",$arrIdt, $identityId);

            $superId=$record['IsSuperuser'];
            $checked=($superId) ? 'checked="checked"' : '';

  			$pass=$record['UserPW'];
  			$name=$record['UserLoginName'];
  			echo "<tr>";
  			echo '<form action="./editUserHandle.php" method="post">';
  			//form
  			 echo "<td><input type=\"text\" name=\"UserName\" value=$name></td>";
  			 echo "<td><input type=\"text\" name=\"password\" value=$pass></td>";
  			 echo "<td><select name=\"Identity\" value=$oIdentity</td>";
             echo "<td><select name=\"Privilege\" value=$oPriv</td>";
             echo "<td><input type=\"checkbox\" select name=\"SuperUser\" value=$superId <?php echo $checked; ?> </td>";
             echo "<td><select name=\"SiteId\" value=$oSiteID</td>";

             echo "<td><button type=\"submit\" class=\"btn btn-primary\">Edit</button></td></form>";
             echo "</tr>";
	    }
    echo "</tbody></table>";
	    ?>
     
     </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="superUser.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>