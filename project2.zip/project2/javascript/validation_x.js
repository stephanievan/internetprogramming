
// validates that name includes only letters and is at least 4 digits long
function validatefield (id) {
	if(/^[a-zA-Z]\w{4,}/.test(id.value))
		return true;
	else
		return false; 
}

// Displays a message while the user is entering in their name of whether it is valid or not
function validatefield (id) {
	errorMsg=document.getElementById("errorNameMsg"); // it is for <p> to show error message
	if(validateName(id))
	{
		errorMsg.innerHTML="Valid Name!";
		errorMsg.className="text-primary";
	}
	else
	{
		errorMsg.innerHTML="Not Valid name!";
		errorMsg.className="text-danger";
	}
}

// doesn't allow invalid input into database
function validate(form) {
	nameId=document.getElementById("nameId");
	identityId=document.getElementById("identity");
	if(validateName(nameId)&&validateName(identityId))
		return true; // submit the form
	else
	{
		msgId=document.getElementById("msgId");
		msgId.innerHTML="Invalid input! Please correct them before submitting!";
		msgId.className="alert alert-danger";	
		return false;
	}
}