function findName () {
	
	var dataList=document.getElementById("nameId");
	var uname=dataList.value;
	if(uname.length>=1)
	{
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
         var strNames= this.responseText;
                var arrNames=strNames.split(" ");
                var opt='';
            //    for (var name of arrNames)
            //    {
            //      opt +='<option value="'+name+'">';
                  
            //     }
            //     document.getElementById("listNames").innerHTML=opt;  
            //    }
        };
	xhttp.open("GET", "./util/uniqueName.php?loginname="+uname, true);
	xhttp.send();
	}
}
}