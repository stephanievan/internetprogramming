<?php       
 // this function generates options for a dropdown of the given field      
 function optionGen($id,$field,$arr,$selectedValue)
 {
   
   $optionStr= "<select id=\"$id\" name=\"$field\">";
               
   foreach ($arr as $item1)
     foreach ($item1 as $key => $value) 
        {
           if ($value==$selectedValue)
             $optionStr.= "<option value=\"$value\" selected>$value</option>";
           else
            $optionStr.= "<option value=\"$value\" >$value</option>";
        }
  $optionStr.=" </select>";
  return $optionStr;
    }
?>