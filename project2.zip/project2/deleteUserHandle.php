<!-- used by deleteUser.php to delete the specified user from tblusers -->
<?php
require_once("sqlSts.php");
$conn=connectDB();

$username=$_POST['loginname'];
	$query="DELETE FROM tblusers WHERE UserLoginName = \"$username\"";
	$result=$conn->query($query);

    
	if(!$result) die("Fatal error from Query");
	else
	header("Location: admin.php?msg=User deleted successfully");


?>