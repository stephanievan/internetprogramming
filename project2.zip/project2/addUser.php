<?php
  ob_start();
  session_start();
  if(!isset($_SESSION['admin']))
{
  header("Location: superuserlogin.php");
  exit(0);
}
?>

<!-- “addUser.php”, which can add personnel to enable access to the database based on different user credentials and requirements. Can enter user details: login name, password, full name, security level,fkSiteIDand then check the box if this will be a superuser.  -->

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style type="text/css">
     .space10 {
      height: 20px;
     }
     .inline-div {
      padding: 35px;
      display:inline-table;
     }
     .info {
      height: 100%;
      width:80%;
     }
     th, td {
      padding:15px;
      text-align:left;
     }
}
    </style>
    <title>Add User</title>
  </head>
  <body>
  <?php
    require_once("pageFormat.php");
    require_once("DBFuncs/sqlConn.php");
    require_once("DBFuncs/sqlSts.php");
    require_once("util/optionSupport.php");

    $conn=connectDB();
    $query="SELECT DISTINCT(UserSecGroup) FROM tblprivileges order by UserSecGroup";;
    $arr1=getResultFromTable($conn, $query);

    if(isset($_POST['loginName']))
    {
      $searchName=$_POST['loginName'];
      $query="SELECT * FROM tblusers WHERE UserLoginName=$loginName ORDER BY UserLoginName";
    }
    else
      $query="SELECT * FROM tblusers ORDER BY UserLoginName";
    
    $arr=getResultFromTable($conn,$query);

    $query="SELECT SiteID FROM tlkpsite";
    $arrSiteID=getResultFromTable($conn,$query);

   pageHeader("Admin", "logo.png");
    echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
              <a class="nav-item nav-link" href="editTest.php">Edit Security Level</a>
              <a class="nav-item nav-link" href="edit.php">Edit Users</a>
              <a class="nav-item nav-link" href="about.php">About</a>
            </nav>
        <hr class="style1"/>
EOT;

  // checks for message from addUserHandler.php
  if(isset($_GET['msg']))
  {
    $msg=$_GET['msg'];
      echo<<<EOT
        <div class="alert" role="alert">
        $msg
        </div>
EOT;
  }
    echo<<<EOT
<div>
<table class="info">
  <form action="addUserHandler.php" method="POST" onsubmit="return validate(this)"  >
      <tr>
        <td colspan = "2">
          Login:<br>
          <!-- required attribute does not let user leave this field empty -->
          <input type="text" name="loginname" id="nameId" onblur="findName()" required>
        </td>
        <td>
          Password:<br>
          <!-- required attribute does not let user leave this field empty. pattern attribute required user to enter a pattern that matches the regular expression. -->
          <input type="password" name="password" id="passId" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        </td>
        <td colspan="2">
          Identity:<br>
           <!-- required attribute does not let user leave this field empty -->
          <input type="text" name="id" id="identity" required>
        </td>
      </tr>
      <tr>
        <td colspan="2">
          Security Level:<br>
EOT;
    // call optionGen() to get options for privilege dropdown
    $oStr=optionGen("securityId", "securityName", $arr1, 0);
    echo "$oStr";
    echo<<<EOT
        </td>
        <td colspan="2">
          Superuser?<br>
          <input type="checkbox" name="suser" value='1'>
        </td>
        <td colspan="2">
          Site ID:<br>
EOT;
    // call optionGen() to get options for fksiteid dropdown
    $oStr=optionGen("siteID","fkSiteID",$arrSiteID, 0);
    echo "$oStr"; 
    echo<<<EOT
        </td>
      </tr>
      <td>
        <input type="submit" value="Add User">
      </form>
      <td>
        <form action="superUserLogout.php">
          <input type="submit" value="Close Form"/>
        </form>
      </td>
    </table>
</div>

EOT;
?>

<script type="text/javascript" src="./javascript/finduname.js"></script>
      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>