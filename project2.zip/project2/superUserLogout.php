<?php
session_start();
// Admin is automatically logged out after session ends 
$_SESSION=array();
setcookie(session_name(), "", time()-2592000, "/");
session_destroy();
header("Location: ./superuserlogin.php");
?>