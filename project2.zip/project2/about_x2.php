<?php
  ob_start();
  session_start();
  if(!isset($_SESSION['admin']))
{
  header("Location: ../superuserlogin.php");
  exit(0);
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style type="text/css">
     .space10 {
      height: 20px;
     }
     .inline-div {
      padding: 35px;
      display:inline-table;
     }
     .info {
      height: 100%;
      width:80%;
     }
     th, td {
      padding:15px;
      text-align:left;
     }
}
    </style>
    <title>About</title>
  </head>
  <body>
  <?php
    require_once("pageFormat.php");
    require_once("DBFuncs/sqlSts.php");
    require_once("DBFuncs/sqlConn.php");
   //pageHeader("Admin", "logo.png");
    echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
               <a class="nav-item nav-link" href="editUser.php">Edit User</a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
              <a class="nav-item nav-link" href="edit.php">Edit Security Level</a>
              <a class="nav-item nav-link" href="about.php">About</a>
            </nav>
        <hr class="style1"/>
EOT;
?>
<h1>About</h1>
Version: 0.6.0<br>
Authors: J. Robbins, S. VanDyke<br>
Emails: john.robbins@bobcats.gcsu.edu, stephanie.vandyke@bobcats.gcsu.edu


</body>