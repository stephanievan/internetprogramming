<?php
  ob_start();
  session_start();
  if(!isset($_SESSION['admin']))
{
  header("Location: superuserlogin.php");
  exit(0);
}
?>

<!-- “DeleteUser.php”, which can remove user from the database. Confirms with the user before deletiing it -->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <style type="text/css">
     .space10 {
      height: 20px;
     }
    </style>
    <title>Delete User</title>
  </head>
  <div class="container">
  <body>
  <?php
    require_once("pageFormat.php");
    pageHeader("Delete User", "logo.png");
     echo<<<EOT
          <!-- Navbar content for admin-->
          <nav class="navbar">
              <a class="nav-item nav-link active" href="addUser.php">Add User<span class="sr-only">(current)</span></a>
              <a class="nav-item nav-link" href="deleteUser.php">Delete User</a>
              <a class="nav-item nav-link" href="editTest.php">Edit Security Level</a>
              <a class="nav-item nav-link" href="edit.php">Edit Users</a>
              <a class="nav-item nav-link" href="about.php">About</a>
            </nav>
        <hr class="style1"/>
EOT;
  ?>

  <form action="./deleteUserHandle.php" method="POST">
      Enter the name of the user you want to delete:<br>
      <input type="text" name="loginname">
      <br><br>
      <input type="submit" value="Delete User" onclick="return confirm('Are you sure you want to delete')">
      <br><br>
    </form> 
    <form action="superUserLogout.php">
          <input type="submit" value="Close Form"/>
        </form>

</body>
