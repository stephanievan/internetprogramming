<!-- Adds a new user to tblusers. Used by addUser.php -->
<?php
$dir=dirname(dirname(__FILE__)); 
require_once("DBFuncs/sqlConn.php");
$conn=connectDB();

if(isset($_POST['loginname']))
{
	$loginname=$_POST['loginname'];
}
$pwd=$_POST['password'];
$identity=$_POST['id'];
$privilege=$_POST['securityName'];
$issuperuser = isset($_POST['suser']) && $_POST['suser']  ? "1" : "0"; // check if checkbox is checked
$siteid=$_POST['fkSiteID'];

$names=array(); //hold a list of names return from SQL
$query="SELECT UserLoginName FROM tblusers WHERE UserLoginName = '$name' ORDER BY UserLoginName";
$arr=getResultFromTable($conn,$query);  //arr['UserLoginName']="mis"....
function getResultFromTable($conn, $query)
{
	//get the content
	$arr=array();
	$result=$conn->query($query);
	if(!$result) die("Fatal Error on query");
	$rows=$result->num_rows;
	if($rows>0)
	{
		header("Location: addUser.php?msg=Username taken. Please enter a new username. ");
    }
    
    $result->free();
    return $arr;
}

$query="INSERT INTO tblusers VALUES(\"$loginname\", sha(\"$pwd\"), \"$identity\", \"$privilege\", \"$issuperuser\", \"$siteid\") ";

$result=$conn->query($query);
if(!$result) die("Fatal error from Query");
else 
	header("Location: addUser.php?msg=User added! ");

?>