<?php
session_start();
// This form checks the database for the matching username and password from superuserlogin.php
require_once("DBFuncs/sqlConn.php");
$conn=connectDB();

$loginname=$_POST['loginname'];
$pwd=$_POST['password'];

$query="SELECT UserLoginName, UserPW, IsSuperuser FROM tblusers WHERE UserLoginName=\"$loginname\" AND UserPW=\"$pwd\" ";

$result=$conn->query($query);
if(!$result) die("Fatal error from Query");

$followingdata = $result->fetch_assoc();
$rows=$result->num_rows;

// start new session
if($rows!=0 && $followingdata['IsSuperuser']!=0)
{
	$_SESSION['admin']='admin';
	$_SESSION['UserLoginName']=$loginname;
	header("Location: admin.php");
}
else
	header("Location: superuserlogin.php?msg=\"Incorrect email or password!\" ");
?>