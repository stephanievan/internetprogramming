<!-- Used by edit.php to edit a user in tblusers -->
<?php
session_start();
require_once("sqlConn.php");
$conn=connectDB();



$userName=$_POST['UserName'];
$pass=$_POST['password'];
$identity=$_POST['Identity'];
$privilege=$_POST['Privilege'];
$superuser=isset($_POST['SuperUser']) && $_POST['SuperUser'] ? '1' :'0';
$siteId=$_POST['SiteId'];



$query="UPDATE tblusers SET UserLoginName=\"$userName\", UserPW=\"$pass\", Identity=\"$identity\", Privilege=\"$privilege\" ,IsSuperuser=\"$superuser\" ,fkSiteID=\"$siteId\" WHERE UserLoginName= \"$userName\" ";

$result=$conn->query($query);
if(!$result) die("Fatal error from Query");
else
	header("Location: edit.php");
?>