<!-- this is used by editTest.php to update privilege and fksiteid in tblusers where userloginname is specified -->
<?php
$dir=dirname(dirname(__FILE__)); 
require_once("DBFuncs/sqlConn.php");
$conn=connectDB();

$username=$_POST['username'];
$privilege=$_POST['securityName'];
$siteid=$_POST['fkSiteID'];

$query="UPDATE tblusers SET Privilege=\"$privilege\", fkSiteID=\"$siteid\" WHERE UserLoginName=\"$username\" ";

$result=$conn->query($query);
if(!$result) die("Fatal error from Query");
else 
	header("Location: edit.php?msg=\"User edited!\" ");

?>